package com.hexaware.service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.hexaware.model.Product;
import com.hexaware.repository.ProductRepository;

/**
 * Service class for managing products.
 */
@Service
public class ProductService {

//    @Autowired
    private final ProductRepository productRepository;

    @Autowired
        public ProductService(ProductRepository productRepository) {
            this.productRepository = productRepository;
        }

    /**
     * Retrieve all products.
     *
     * @return list of all products
     */
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Retrieve a product by its ID.
     *
     * @param id the product ID
     * @return the product, or null if not found
     */
    public Product getProductById(Long id) {
        Optional<Product> product = productRepository.findById(id);
        return product.orElse(null);
    }

    /**
     * Create a new product.
     *
     * @param product the product to create
     * @return the created product
     */
    public Product createProduct(@Valid Product product) {
        return productRepository.save(product);
    }

    /**
     * Update an existing product.
     *
     * @param id the product ID
     * @param product the product data to update
     * @return the updated product, or null if not found
     */
    public Product updateProduct(Long id, @Valid Product product) {
        if (!productRepository.existsById(id)) {
            return null;
        }
        product.setId(id);
        return productRepository.save(product);
    }

    /**
     * Delete a product by its ID.
     *
     * @param id the product ID
     */
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}
