package com.hexaware.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hexaware.model.Product;

/**
 * Repository interface for Product entity.
 * Provides CRUD operations and query methods for products.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    /**
     * Find products by category.
     *
     * @param category the category to filter by
     * @return list of products in the given category
     */
    List<Product> findByCategory(String category);
}
